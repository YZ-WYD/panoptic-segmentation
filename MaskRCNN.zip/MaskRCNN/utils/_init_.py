# utils/__init__.py
from .utils import make_anchor_generator   # 把函数提升到包顶层